from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, user, passwd):
        # Initializing the MongoClient. This helps to 
        #access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        #unique to the individual Apporto environment.
        #
        # Connection Variables
        #
        # USER = 'aacuser' commented out because it was hardcoded
        # PASS = 'SNHU' commented out because it was hardcoded
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32867
        DB = 'AAC'
        COL = 'animals'
        
        # Debugging statement
        print(f"Initializing with user={user}, passwd={passwd}")
        
        #
        # Initialize Connection
        #
        try:
            self.client = MongoClient(f'mongodb://{user}:{passwd}@{HOST}:{PORT}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except Exception as e:
            raise Exception(f"Could not connect to MongoDB: {e}")
            
        # This was my old code prior to dynamic login/authentication
        # self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        # self.database = self.client['%s' % (DB)]
        # self.collection = self.database['%s' % (COL)]
        
        
    # Create method to implement the C in CRUD        
    def create(self, data):
        if data is not None:
            try:
                self.database.animals.insert_one(data) # data should be dictionary
                return True
            except Exception as e:
                print(f"Error inserting document: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
    # Create method to implement the R in CRUD
    def read(self, data):
        # If data is not None and result is queried, return the result
        if data is not None:
            try:
                return list(self.collection.find(data)) # Query data
            except Exception as e:
                print(f"Error reading document: {e}")
                return []  # return empty list
        # else return empty list
        else:
            raise Exception("Query parameter cannot be None")
            
    # Create method to implement the U in CRUD
    def update(self, query, new_values, update_many=False):
        if query is not None and new_values is not None:
            try:
                update_op = {'$set': new_values} # Wrap updates under $set operator
                if update_many:
                    result = self.collection.update_many(query, update_op)
                else:
                    result = self.collection.update_one(query, update_op)
                return result.modified_count #returns number of updated documents
            except Exception as e:
                print(f"Error updating document(s): {e}")
                return 0
        else:
            raise Exception("Both query and new values must be provided.")
            
    # Create method to implement the D in CRUD
    def delete(self, data, delete_many=False):
        if data is not None:
            try:
                if delete_many:
                    result = self.collection.delete_many(data) # delete many documents
                else:
                    result = self.collection.delete_one(data) # delete single document
                return result.deleted_count # returns number of deleted documents
            except Exception as e:
                print(f"Error deleting document(s): {e}")
                return 0
        else:
            raise Exception("Query parameter cannot be None.")
